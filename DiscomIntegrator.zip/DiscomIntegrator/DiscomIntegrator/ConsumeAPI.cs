﻿using Ionic.Zip;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading;

namespace DiscomIntegrator
{
    /// <summary>
    /// Author - Tanmaya Kumar Jena
    /// DOC - 20-11-2017
    /// 
    /// </summary>
    public class ConsumeAPI
    {
        #region Declaration
        private static int bufferSize = 2048;
        private static string baseFtp = ConfigurationManager.AppSettings["FTP-BASE-URI"];
        private static string ftpUnm = ConfigurationManager.AppSettings["FTP-USER-NAME"];
        private static string ftpPwd = ConfigurationManager.AppSettings["FTP-PASSWORD"];
        private static string ftpUploadPath = ConfigurationManager.AppSettings["FTP-UPLOAD-PATH"];
        //private static string ftpDownloadPath = ConfigurationManager.AppSettings["FTP-DOWNLOAD-PATH"];
        //private static Uri uri = new Uri(ConfigurationManager.AppSettings["API-FILEUPLOAD"]);
        private static string localTargetPath = ConfigurationManager.AppSettings["FILE-PATH"];
        private static string appLogPath = ConfigurationManager.AppSettings["APP-LOG-PATH"];
        private static string errorLogPath = ConfigurationManager.AppSettings["ERROR-LOG-PATH"];
        private static string apiUploaderLastLogUri = ConfigurationManager.AppSettings["API-LAST-UPLOADER-LOG-URI"];
        private static string apiLastLogUri = ConfigurationManager.AppSettings["API-LAST-LOG-URI"];
        private static Uri apiDownload = new Uri(ConfigurationManager.AppSettings["API-FILEDOWNLOAD"]);
        private static Uri apiUpload = new Uri(ConfigurationManager.AppSettings["API-FILE-UPLOAD"]);
        private static Uri apiInsertUploaderLastLog = new Uri(ConfigurationManager.AppSettings["API-INSERT-UPLOADER-LOG-URI"]);
        //private static string locTempPath = ConfigurationManager.AppSettings["LOCAL-PATH-TEMP"];
        //private static string tempPath = ConfigurationManager.AppSettings["TempPath"];
        //private static string CtlPath = ConfigurationManager.AppSettings["CtlPath"];
        #endregion

        #region Progress Download Events
        void WebClientDownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            try
            {
                Console.WriteLine("Download status: {0}%.", e.ProgressPercentage);
                Console.Read();
                if (e.ProgressPercentage == 100)
                {
                    long bit = e.BytesReceived;
                    HandelClientResponse(appLogPath, "Data downloaded successfully", e.BytesReceived, errorLogPath);
                }
            }
            catch (Exception ex)
            {
                HandelClientException(errorLogPath, ex.Message);
            }
        }

        void WebClientDownloadCompleted(object sender, DownloadDataCompletedEventArgs e)
        {
            Console.WriteLine("Download finished!");
            Console.Read();
        }
        #endregion

        #region Main Methods
        public void UploadFiles()
        {
            try
            {
                if (CheckNet())
                {
                    string lastUploaderLog = GetLastLogs(apiUploaderLastLogUri + "R");
                    List<JObject> jsonObjList = JsonConvert.DeserializeObject<List<JObject>>(lastUploaderLog);

                    if (jsonObjList != null)
                    {
                        if (jsonObjList.Count > 0)
                        {
                            foreach (JObject item in jsonObjList)
                            {
                                string sysType = (string)item["sysType"];
                                string csvfile = (string)item["csvfile"];
                                string locCd = (string)item["locCd"];
                                string billMonth = (string)item["billMonth"];
                                string grNo = (string)item["grNo"];
                                string part = (string)item["part"];
                                string startDate = (string)item["startDate"];
                                string endDate = (string)item["endDate"];

                                string paramInputs = string.Format("{0}/{1}/{2}/{3}/{4}/{5}/{6}", sysType, csvfile, locCd, billMonth, grNo, startDate.Replace(":", "$"), endDate.Replace(":", "$"));
                                DownloadUploadFiles(apiDownload, paramInputs, localTargetPath, ftpUploadPath, baseFtp, ftpUnm, ftpPwd, locCd, grNo, part, billMonth, startDate, endDate, sysType);
                                //InsertUploaderLastLog(apiInsertUploaderLastLog, billMonth, locCd, grNo, startDate, endDate, part);
                            }
                        }
                        // DownloadBillingFile(string sysType, string csvfile, string locCd, string billMonth, string grNo, string startDate, string endDate)
                        else
                        {
                            HandelClientException(errorLogPath, "Files not generated for upload process");
                        }
                    }
                    else
                    {
                        HandelClientException(errorLogPath, "Files not generated for upload process");
                    }
                }
                else
                {
                    HandelClientException(errorLogPath, "Connectivity error, check internet");
                }
            }
            catch (Exception ex)
            {
                HandelClientException(errorLogPath, ex.Message);
            }
        }
        #endregion

        #region Get All CCNB Loccd/Group/Billmonth/Part
        private string GetLastLogs(string remoteUri)
        {
            string result = string.Empty;
            try
            {
                var request = (HttpWebRequest)WebRequest.Create(remoteUri);
                request.Method = WebRequestMethods.Http.Get;
                request.ContentType = "application/json; charset=utf-8";
                request.Timeout = 1000000;
                request.AllowWriteStreamBuffering = false;

                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    using (var sr = new StreamReader(response.GetResponseStream()))
                    {
                        result = sr.ReadToEnd();
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                HandelClientException(errorLogPath, ex.Message);
                return result;
            }
        }
        #endregion

        #region Methods To GenarateDownloadUploadFiles
        private void DownloadUploadFiles(Uri apiDowndloadURI, string apiDndURIParams, string locsourcePath, string targetPath, string ftpUri, string ftpUnm, string ftpPwd, string locCd, string grp, string part, string billMonth, string startDate, string endDate, string sysType)
        {
            if (!Directory.Exists(locsourcePath))
            { Directory.CreateDirectory(locsourcePath); }
            string tempfilePath = "", localTargetTempPath = "", starttime = "", endtime = "", Status = "1", error = "0", errmessage = "-";
            starttime = DateTime.Now.ToString();

            Uri apiDndURI = new Uri(string.Format("{0}/{1}", apiDowndloadURI, apiDndURIParams));
            Guid folderId = Guid.NewGuid();
            using (var client = new WebClient())
            {
                localTargetTempPath = string.Format("{0}{1}_{2}/", locsourcePath, folderId, DateTime.Now.ToString().Replace(":", "-"));
                tempfilePath = string.Format("{0}Temp.zip", localTargetTempPath);

                if (!Directory.Exists(localTargetTempPath))
                { Directory.CreateDirectory(localTargetTempPath); }

                //client.Credentials = new NetworkCredential("enserv", "enserv", "FVLDELHO");
                client.DownloadDataCompleted += WebClientDownloadCompleted;
                client.DownloadProgressChanged += WebClientDownloadProgressChanged;
                client.DownloadFileAsync(apiDndURI, tempfilePath);
                while (client.IsBusy)
                {
                    Thread.Sleep(100);
                }

                if (File.Exists(tempfilePath))
                {
                    using (ZipFile objzip = ZipFile.Read(tempfilePath))
                    {
                        objzip.ExtractAll(localTargetTempPath, ExtractExistingFileAction.OverwriteSilently);
                    }
                }
            }

            DirectoryInfo dInfo = new DirectoryInfo(localTargetTempPath);
            foreach (FileInfo finfo in dInfo.EnumerateFiles("*.txt*", SearchOption.AllDirectories))
            {
                string Length = "", totRcd = "";
                try
                {
                    Length = finfo.Length.ToString();

                    if (double.Parse(Length) != 0)
                    {
                        totRcd = File.ReadAllLines(finfo.FullName).Length.ToString();
                        error = "0";

                        if (sysType != "R")
                        {
                            sysType = "C";
                            UploadFileToFTP(localTargetTempPath + finfo.Name, ftpUri + targetPath, ftpUnm, ftpPwd);
                            endtime = DateTime.Now.ToString();
                            HandelClientResponse(appLogPath, "Data uploaded successfully to ftp", finfo.Length, errorLogPath);
                        }
                        else
                        {
                            sysType = "R";
                            ProcessRMSData(finfo.Directory + "/" + finfo.Name);
                            endtime = DateTime.Now.ToString();
                            HandelClientResponse(appLogPath, "Data uploaded successfully to discom db", finfo.Length, errorLogPath);
                        }
                    }
                }
                catch (Exception ex)
                {
                    error = "1";
                    errmessage = ex.Message;
                    HandelClientException(errorLogPath, errmessage);
                }
                finally  
                {
                    if (double.Parse(Length) != 0)
                    {
                        endtime = DateTime.Now.ToString();
                        InsertUploadLog(finfo.Name, localTargetTempPath, Length, locCd, grp, part, billMonth, startDate, endDate, sysType, starttime, endtime, totRcd, "0", "0", Status, error, errmessage, "0", "N");
                    }
                }
            }
        }
        #endregion

        #region Methods for Upload Files to Client FTP
        private void UploadFileToFTP(string sourcePath, string ftpurl, string ftpusername, string ftppassword)
        {
            //try
            //{
            string filename = Path.GetFileName(sourcePath);
            string ftpfullpath = ftpurl;

            FtpWebRequest ftp = (FtpWebRequest)FtpWebRequest.Create(ftpurl + filename);
            ftp.Credentials = new NetworkCredential(ftpusername, ftppassword);

            ftp.KeepAlive = true;
            ftp.UseBinary = true;
            ftp.Method = WebRequestMethods.Ftp.UploadFile;

            FileStream fs = File.OpenRead(sourcePath);
            byte[] buffer = new byte[fs.Length];
            fs.Read(buffer, 0, buffer.Length);
            fs.Close();

            Stream ftpstream = ftp.GetRequestStream();
            ftpstream.Write(buffer, 0, buffer.Length);
            ftpstream.Close();
            //}
            //catch (Exception ex)
            //{
            //    HandelClientException(errorLogPath, ex.Message);
            //}
        }
        #endregion

        #region Methods for Handle Logs
        /// <summary>
        /// used to write exception log to a text file in log path
        /// </summary>
        /// <param name="logPath"></param>
        /// <param name="exception"></param>
        private void HandelClientException(string logPath, string exception)
        {
            string log_message = "";
            string log_File = string.Format("{0}/{1}_{2}.txt", Path.GetDirectoryName(logPath), Path.GetFileNameWithoutExtension(logPath), DateTime.Now.Date.ToString("dd-MM-yyyy"));
            StreamWriter tw = File.AppendText(log_File);
            try
            {
                if (!File.Exists(log_File))
                {
                    File.Create(log_File);
                }

                log_message = string.Format("{0}----{1}", DateTime.Now.ToString(), exception);
                // write a line of text to the file
                tw.WriteLine(log_message);
            }
            catch (Exception ex)
            {
                log_message = string.Format("{0}----{1}", DateTime.Now.ToString(), ex.Message);
                // write a line of text to the file
                tw.WriteLine(log_message);
            }
            finally
            {
                // close the stream
                tw.Close();
            }
        }
        /// <summary>
        /// used to write success log to a text file in log path
        /// </summary>
        /// <param name="logPath"></param>
        /// <param name="exception"></param>
        private void HandelClientResponse(string appLogPath, string message, long byteReceived, string errorLogPath)
        {
            string log_message = "";
            string app_log_File = string.Format("{0}/{1}_{2}.txt", Path.GetDirectoryName(appLogPath), Path.GetFileNameWithoutExtension(appLogPath), DateTime.Now.Date.ToString("dd-MM-yyyy"));
            StreamWriter tw = File.AppendText(app_log_File);
            try
            {
                if (!File.Exists(app_log_File))
                {
                    File.Create(app_log_File);
                }
                string fileSize = string.Format("{0} MB", Math.Round((double)byteReceived / 1048576, MidpointRounding.AwayFromZero));
                log_message = string.Format("{0}--{1} Bytes Downloaded--{2}", DateTime.Now.ToString(), fileSize, message);
            }
            catch (Exception ex)
            {
                HandelClientException(errorLogPath, ex.Message);
            }
            finally
            {
                // write a line of text to the file
                tw.WriteLine(log_message);
                // close the stream
                tw.Close();
            }
        }
        #endregion

        #region InsertLogtoDB
        //public HttpResponseMessage InsertUploader(string fileName, string filePath, string fileSize, string locCd, string grNo, string part, string systemType, string processStartTime, string processEndTime, string totalRecords, string recordsProcessed, string recordsFailed, string fileStatus, string isError, string errorMessage, string actionTaken, string isRetry)
        private void InsertUploadLog(string name, string path, string size, string locCd, string grp, string part, string billMonth, string startDate, string endDate, string sysType, string startTime, string endTime, string totRecords, string rcdProcess, string rcdFailed, string fileStatus, string isError, string errMsg, string action, string isTry)
        {
            try
            {
                path = path.Replace("/", "--").Replace(":", "$");
                startTime = startTime.Replace(":", "$");
                endTime = endTime.Replace(":", "$");
                startDate = startDate.Replace(":", "$");
                endDate = endDate.Replace(":", "$");
                errMsg = errMsg.Replace(":", "$");

                Uri apiURI = new Uri(string.Format("{0}/{1}/{2}/{3}/{4}/{5}/{6}/{7}/{8}/{9}/{10}/{11}/{12}/{13}/{14}/{15}/{16}/{17}/{18}/{19}/{20}", apiUpload, name, path, size, locCd, grp, part, billMonth, startDate, endDate, sysType, startTime, endTime, totRecords, rcdProcess, rcdFailed, fileStatus, isError, errMsg, action, isTry));

                using (var client = new WebClient())
                {
                    client.Headers.Add("Content-Type:application/json");
                    client.Headers.Add("Accept:application/json");
                    var result = client.DownloadString(apiURI);
                }
            }
            catch (Exception ex)
            {
                HandelClientException(errorLogPath, ex.Message);
            }
        }

        private void InsertUploaderLastLog(Uri insertLastLogUri, string billmonth, string loccd, string grno, string startdate, string enddate, string partno)
        {
            try
            {
                Uri apiURI = new Uri(string.Format("{0}/{1}/{2}/{3}/{4}/{5}/{6}/", insertLastLogUri, billmonth, loccd, grno, startdate.Replace(":", "$"), enddate.Replace(":", "$"), partno));

                using (var client = new WebClient())
                {
                    client.Headers.Add("Content-Type:application/json");
                    client.Headers.Add("Accept:application/json");
                    var result = client.DownloadString(apiURI);
                }
            }
            catch (Exception ex)
            {
                HandelClientException(errorLogPath, ex.Message);
            }
        }
        #endregion

        #region Get Mac Address
        /// <summary>
        /// returns the mac address of system
        /// </summary>
        /// <returns></returns>
        private string GetMACAddress()
        {
            try
            {
                NetworkInterface[] nics = NetworkInterface.GetAllNetworkInterfaces();
                String sMacAddress = string.Empty;
                foreach (NetworkInterface adapter in nics)
                {
                    if (sMacAddress == String.Empty)// only return MAC Address from first card
                    {
                        IPInterfaceProperties properties = adapter.GetIPProperties();
                        sMacAddress = adapter.GetPhysicalAddress().ToString();
                    }
                } return sMacAddress;
            }
            catch (Exception ex)
            {
                HandelClientException(errorLogPath, ex.Message);
                return string.Empty;
            }
        }
        #endregion

        #region Process RMS data to Discom DB
        public void ProcessRMSData(string sourceFilePath)
        {

            string[] csvLines = File.ReadAllLines(sourceFilePath);
            StringBuilder csvString = new StringBuilder();

            foreach (string csvLine in csvLines)
            {
                try
                {
                    string[] values = csvLine.Split('$');
                    int no_col = values.GetUpperBound(0);
                    if (no_col >= 10)
                    {
                        InsertDataToClientDB(values);
                    }
                }
                catch (Exception ex)
                {
                    HandelClientException(errorLogPath, ex.Message);
                }
            }
        }

        private void InsertDataToClientDB(string[] values)
        {
            string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString.ToString();

            using (OracleConnection connection = new OracleConnection(ConnectionString))
            {
                using (OracleCommand command = new OracleCommand("SP_RMSUPLOAD", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("c_select", OracleDbType.Int16).Direction = ParameterDirection.Output;//
                    command.Parameters.Add("P_IVRSID", OracleDbType.Varchar2).Value = values[0].ToString().Trim();
                    command.Parameters.Add("P_CONS_NAME", OracleDbType.Varchar2).Value = values[1].ToString().Trim();
                    command.Parameters.Add("P_ADD0", OracleDbType.Varchar2).Value = values[2].ToString().Trim();
                    command.Parameters.Add("P_ADD1", OracleDbType.Varchar2).Value = values[3].ToString().Trim();
                    command.Parameters.Add("P_ADD3", OracleDbType.Varchar2).Value = values[4].ToString().Trim();
                    command.Parameters.Add("P_CITY", OracleDbType.Varchar2).Value = values[5].ToString().Trim();
                    command.Parameters.Add("P_BILL_MON", OracleDbType.Varchar2).Value = values[6].ToString().Trim();
                    command.Parameters.Add("P_BILL_ISSUE_DATE", OracleDbType.Varchar2).Value = values[7].ToString().Trim();
                    command.Parameters.Add("P_FIRST_CHQ_DUE_DATE", OracleDbType.Varchar2).Value = values[8].ToString().Trim();
                    command.Parameters.Add("P_BILL_NET", OracleDbType.Varchar2).Value = values[9].ToString().Trim();
                    command.Parameters.Add("P_TATAMT_AFTER_DUE_DT", OracleDbType.Varchar2).Value = values[10].ToString().Trim();

                    //command.Parameters.Add(new OracleParameter("P_IVRSID", values[0].ToString().Trim()));
                    //command.Parameters.Add(new OracleParameter("P_CONS_NAME", values[1].ToString().Trim()));
                    //command.Parameters.Add(new OracleParameter("P_ADD0", values[2].ToString().Trim()));
                    //command.Parameters.Add(new OracleParameter("P_ADD1", values[3].ToString().Trim()));
                    //command.Parameters.Add(new OracleParameter("P_ADD3", values[4].ToString().Trim()));
                    //command.Parameters.Add(new OracleParameter("P_CITY", values[5].ToString().Trim()));
                    //command.Parameters.Add(new OracleParameter("P_BILL_MON", values[6].ToString().Trim()));
                    //command.Parameters.Add(new OracleParameter("P_BILL_ISSUE_DATE", values[7].ToString().Trim()));
                    //command.Parameters.Add(new OracleParameter("P_FIRST_CHQ_DUE_DATE", values[8].ToString().Trim()));
                    //command.Parameters.Add(new OracleParameter("P_BILL_NET", decimal.Parse(values[9].ToString().Trim())));
                    //command.Parameters.Add(new OracleParameter("P_TATAMT_AFTER_DUE_DT", decimal.Parse(values[10].ToString().Trim())));
                    command.Connection.Open();
                    command.ExecuteNonQuery();
                    command.Connection.Close();
                }
            }
        }

        //public void ProcessData(string sourcePath, string ctlPath)
        //{
        //    try
        //    {
        //        //string tempPath = tempPath;
        //        if (!Directory.Exists(tempPath))
        //        {
        //            Directory.CreateDirectory(tempPath);
        //        }
        //        string sourceFilename = Path.GetFileName(sourcePath);
        //        //string ctlFilename = "rmsupload.ctl"; //Path.GetFileName(ctlPath);
        //        string ctlWithoutEx = Path.GetFileNameWithoutExtension(ctlPath);
        //        string guid = Guid.NewGuid().ToString();
        //        string tempTargetPath = tempPath + "\\" + guid;
        //        string targetSourceFile = tempTargetPath + "\\" + sourceFilename;
        //        string targetCtlFile = tempTargetPath + "\\" + ctlPath;
        //        Directory.CreateDirectory(tempPath + guid);
        //        File.Copy(sourcePath, tempTargetPath + "\\" + "rms.csv");
        //        File.Copy(ctlPath, tempTargetPath + "\\" + "rmsupload.ctl");
        //        ImportTODB(tempTargetPath, "rmsupload");
        //    }
        //    catch (Exception ex)
        //    {
        //        HandelClientException(errorLogPath, ex.Message);
        //    }
        //}

        private void ImportTODB(string tempFolderPath, string ctlFile)
        {
            Process myProcess = new Process();
            try
            {
                ProcessStartInfo prc = new ProcessStartInfo();

                prc.WorkingDirectory = tempFolderPath;
                prc.FileName = System.Configuration.ConfigurationManager.AppSettings["SQLLOADER"];
                prc.Arguments = @" enserv/enserv@172.18.0.46:1521/powerbkp control=" + ctlFile + ".ctl log=" + ctlFile + ".log bad=" + ctlFile + ".bad bindsize=209715200 readsize=209715200 rows=200000 Errors=2500000";
                prc.ErrorDialog = true;
                prc.CreateNoWindow = true;
                myProcess = Process.Start(prc);
            }
            catch (Exception ex)
            {
                HandelClientException(errorLogPath, ex.Message);
            }
            finally
            {
                myProcess.WaitForExit();
                myProcess.Close();
            }
        }
        #endregion

        #region Methods To Check Connectivity
        [System.Runtime.InteropServices.DllImport("wininet.dll")]
        private extern static bool InternetGetConnectedState(out int description, int reservedValue);

        public static bool CheckNet()
        {
            int desc;
            return InternetGetConnectedState(out desc, 0);
        }

        private bool CheckNetConnection()
        {
            try
            {
                Ping myPing = new Ping();
                String host = "www.google.com.mx";
                byte[] buffer = new byte[32];
                int timeout = 1000;
                PingOptions pingOptions = new PingOptions();
                PingReply reply = myPing.Send(host, timeout, buffer, pingOptions);
                return (reply.Status == IPStatus.Success);
            }
            catch (Exception)
            {
                return false;
            }

        }
        #endregion

        //public void upload(string remoteFile, string localFile, string host, string user, string pass)
        //{
        //    try
        //    {
        //        /* Create an FTP Request */
        //        FtpWebRequest ftpRequest = (FtpWebRequest)FtpWebRequest.Create(host + remoteFile);
        //        /* Log in to the FTP Server with the User Name and Password Provided */
        //        ftpRequest.Credentials = new NetworkCredential(user, pass);
        //        /* When in doubt, use these options */
        //        ftpRequest.UseBinary = true;
        //        ftpRequest.UsePassive = true;
        //        ftpRequest.KeepAlive = true;
        //        /* Specify the Type of FTP Request */
        //        ftpRequest.Method = WebRequestMethods.Ftp.UploadFile;
        //        /* Establish Return Communication with the FTP Server */
        //        Stream ftpStream = ftpRequest.GetRequestStream();
        //        /* Open a File Stream to Read the File for Upload */
        //        FileStream localFileStream = File.OpenRead(localFile);
        //        /* Buffer for the Downloaded Data */
        //        byte[] byteBuffer = new byte[localFileStream.Length];
        //        int bytesSent = localFileStream.Read(byteBuffer, 0, bufferSize);
        //        /* Upload the File by Sending the Buffered Data Until the Transfer is Complete */
        //        try
        //        {
        //            while (bytesSent != 0)
        //            {
        //                ftpStream.Write(byteBuffer, 0, bytesSent);
        //                bytesSent = localFileStream.Read(byteBuffer, 0, bufferSize);
        //            }
        //        }
        //        catch (Exception ex) { Console.WriteLine(ex.ToString()); }
        //        /* Resource Cleanup */
        //        localFileStream.Close();
        //        ftpStream.Close();
        //        ftpRequest = null;
        //    }
        //    catch (Exception ex) { Console.WriteLine(ex.ToString()); }
        //    return;
        //}

        //private void DownloadFileFromFtp(string userName, string password, string ftpSourceFilePath, string localDestinationFilePath)
        //{
        //    try
        //    {
        //        int bytesRead = 0;
        //        byte[] buffer = new byte[1024];

        //        FtpWebRequest request = CreateFtpWebRequest(ftpSourceFilePath, userName, password, true);
        //        request.Method = WebRequestMethods.Ftp.DownloadFile;

        //        Stream reader = request.GetResponse().GetResponseStream();
        //        BinaryWriter writer = new BinaryWriter(File.Open(localDestinationFilePath, FileMode.CreateNew));

        //        while (true)
        //        {
        //            bytesRead = reader.Read(buffer, 0, buffer.Length);

        //            if (bytesRead == 0)
        //                break;

        //            writer.Write(buffer, 0, bytesRead);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        HandelClientException(errorLogPath, ex.Message);
        //    }
        //}

        //private FtpWebRequest CreateFtpWebRequest(string ftpDirectoryPath, string userName, string password, bool keepAlive = false)
        //{
        //    FtpWebRequest request = (FtpWebRequest)WebRequest.Create(new Uri(ftpDirectoryPath));

        //    //Set proxy to null. Under current configuration if this option is not set then the proxy that is used will get an html response from the web content gateway (firewall monitoring system)
        //    request.Proxy = null;

        //    request.UsePassive = true;
        //    request.UseBinary = true;
        //    request.KeepAlive = keepAlive;

        //    request.Credentials = new NetworkCredential(userName, password);

        //    return request;
        //}



        //private string GetLastLog(string uri)
        //{
        //    try
        //    {
        //        using (var client = new WebClient())
        //        {
        //            client.Headers.Add("Content-Type:application/json");
        //            client.Headers.Add("Accept:application/json");
        //            var result = client.DownloadString(uri);

        //            return result;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "";
        //        HandelClientException(errorLogPath, ex.Message);
        //    }
        //}
    }
}
