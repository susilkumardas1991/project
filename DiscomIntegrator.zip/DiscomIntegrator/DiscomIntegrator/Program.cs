﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DiscomIntegrator
{
    public class Program
    {
        private static string errorLogPath = ConfigurationManager.AppSettings["ERROR-LOG-PATH"];
        static void Main(string[] args)
        {
            try
            {
                ConsumeAPI objget = new ConsumeAPI();
                objget.UploadFiles();
                //objget.testDwd();
            }
            catch (Exception ex)
            {
                string log_message = "";
                string log_File = string.Format("{0}/{1}_{2}.txt", Path.GetDirectoryName(errorLogPath), Path.GetFileNameWithoutExtension(errorLogPath), DateTime.Now.Date.ToString("dd-MM-yyyy"));
                StreamWriter tw = File.AppendText(log_File);
                try
                {
                    if (!File.Exists(log_File))
                    {
                        File.Create(log_File);
                    }
                    log_message = string.Format("{0}----{1}", DateTime.Now.ToString(), ex.Message);
                }
                catch (Exception exx)
                {
                    log_message = string.Format("{0}----{1}", DateTime.Now.ToString(), exx.Message);

                }
                finally
                {
                    // write a line of text to the file
                    tw.WriteLine(log_message);
                    // close the stream
                    tw.Close();
                }
            }
        }
    }
}
