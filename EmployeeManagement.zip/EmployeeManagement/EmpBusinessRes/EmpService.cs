﻿using EmpDataAccess;
using EmpModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpBusinessRes
{
    public class EmpServices : IEmpService
    {
        private static EmpContext _db = new EmpContext();
        EmpDbSeivice empDbSeivice = new EmpDbSeivice();

        //public EmpServices(EmpDbSeivice _empDbSeivice)
        //{
        //    empDbSeivice = _empDbSeivice;
        //}

        public Employee Create(Employee emp)
        {
            var data = empDbSeivice.Create(emp);
            if (data != null)
            {
                return emp;
            }
            return null;
        }

        public List<Employee> GetEmployee()
        {
            List<Employee> emp = empDbSeivice.GetEmployee();
            return emp;
        }

        public List<Employee> GetEmployeeByID(int id)
        {
            List<Employee> emp = empDbSeivice.GetEmployeeByID(id);
            return emp;
        }

        public int Delete(int id)
        {
            try
            {
                var empuser = empDbSeivice.DeleteEmpById(id);
                return id;

            }
            catch (Exception ex)
            {
                return 0;
            }
        }
    }
}
