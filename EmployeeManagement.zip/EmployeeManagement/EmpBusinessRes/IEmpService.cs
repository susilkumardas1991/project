﻿using EmpModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpBusinessRes
{
    public interface IEmpService
    {
        List<Employee> GetEmployee();
        List<Employee> GetEmployeeByID(int id);
        Employee Create(Employee emp);
        int Delete(int id);
    }
}
