﻿using System;
using System.Collections.Generic;
using EmpBusinessRes;
using EmpDataAccess;
using EmpModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace EmpBusinessResTest
{
    [TestClass]
    public class EmpBusinessTest
    {
        private Mock<EmpDbSeivice> _mockIssueSource = new Mock<EmpDbSeivice>();
        private EmpServices _empservice;
        public EmpBusinessTest()
        {
            _empservice = new EmpServices();
            //_mockIssueSource.Object
        }

        [TestMethod]
        public void GetEmployee()
        {
            List<Employee> emp = _empservice.GetEmployee();
            Assert.AreEqual("Susil Kumar Das", emp[0].Name);
        }
        [TestMethod]
        public void GetEmployeeById()
        {
            List<Employee> emp = _empservice.GetEmployeeByID(4);
            Assert.AreEqual("Susil Kumar Das", emp[0].Name);
        }
        [TestMethod]
        public void EmployeeCreate()
        {
            Employee employee = new Employee
            {
                Name = "Susil Kumar Das",
                DepartmentId = 1,
                Salary = 40000,
                EmailAddress = "test@gmail.com",
                PhoneNumber = "9778089858",
                Address = "Mindtree Kalinga",
                RmName = "Umashankar"
            };
            Employee emp = _empservice.Create(employee);
            Assert.AreEqual("Susil Kumar Das", emp.Name);
        }
        [TestMethod]
        public void DeleteEmployee()
        {
            int id = _empservice.Delete(4);
            Assert.AreEqual(4, id);
        }
    }
}
