﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace EmpBusinessTest
{
    [TestClass]
    public class TestEmpBusiness
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
