﻿using EmpModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpDataAccess
{
    public class EmpDbSeivice
    {
        EmpContext _context = new EmpContext();

        //public EmpDbSeivice(EmpContext db)
        //{
        //    _context = db;
        //}

        public Employee Create(Employee emp)
        {
            try
            {
                _context.Employees.Add(emp);
                _context.SaveChanges();
                return emp;
            }
            catch (EmpServiceException ex)
            {
                throw new EmpServiceException("User not saved due to '" + ex.Message + "'");
            }

        }

        public List<Employee> GetEmployee()
        {
            var emp = _context.Employees.ToList();
            return (List<Employee>)emp;
        }

        public List<Employee> GetEmployeeByID(int id)
        {
            if (id <= 0)
            {
                return null;
            }
            List<Employee> emp = _context.Employees.Where(x => x.Id == id).ToList();
            if (emp != null)
            {
                return emp;
            }
            return null;
        }

        public int DeleteEmpById(int id)
        {
            var user = _context.Employees.Find(id);
            if (user != null)
            {
                _context.Employees.Remove(user);
                _context.SaveChanges();
                return id;
            }
            return 0;
        }

    }
}
