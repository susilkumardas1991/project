﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpDataAccess
{
    public class EmpServiceException : System.Exception
    {
        public EmpServiceException()
        { }

        public EmpServiceException(string message)
            : base(message)
        { }

        public EmpServiceException(string message, System.Exception innerException)
            : base(message, innerException)
        { }
    }
}
