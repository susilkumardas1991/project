﻿using System;
using System.Collections.Generic;
using EmpDataAccess;
using EmpModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace EmpDataAccessTest
{
    [TestClass]
    public class EmpDataAccessTest
    {
        private static EmpContext _db = new EmpContext();
        private Mock<EmpDbSeivice> _mockIssueSource = new Mock<EmpDbSeivice>();
        private EmpDbSeivice empdb= new EmpDbSeivice();
        //public EmpDataAccessTest(EmpContext db)
        //{
        //    _db = db;
        //}
       
        //public EmpDataAccessTest()
        //{
        //    _empservice = new EmpDbSeivice();
        //    //_mockIssueSource.Object
        //}

        [TestMethod]
        public void GetEmployee()
        {
            List<Employee> emp = empdb.GetEmployee();
            Assert.AreEqual("Susil Kumar Das", emp[0].Name);
        }
        [TestMethod]
        public void GetEmployeeById()
        {
            List<Employee> emp = empdb.GetEmployeeByID(4);
            Assert.AreEqual("Susil Kumar Das", emp[0].Name);
        }
        [TestMethod]
        public void EmployeeCreate()
        {
            Employee employee = new Employee
            {
                Name = "Susil Kumar Das",
                DepartmentId = 1,
                Salary = 40000,
                EmailAddress = "test@gmail.com",
                PhoneNumber = "9778089858",
                Address = "Mindtree Kalinga",
                RmName = "Umashankar"
            };
            Employee emp = empdb.Create(employee);
            Assert.AreEqual("Susil Kumar Das", emp.Name);
        }
        [TestMethod]
        public void DeleteEmployee()
        {
            int id = empdb.DeleteEmpById(4);
            Assert.AreEqual(4, id);
        }
    }
}
