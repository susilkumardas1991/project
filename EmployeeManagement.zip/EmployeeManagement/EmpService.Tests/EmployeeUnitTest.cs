﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EmpBusinessRes;
using EmpModel;
using EmpService.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace EmpService.Tests
{
    [TestClass]
    public class EmployeeUnitTest
    {
        //public IEmpService _iempService;

        private Mock<IEmpService> _mockIssueSource = new Mock<IEmpService>();
        private EmployeeServiceController controller;

        public EmployeeUnitTest()
        {
            controller = new EmployeeServiceController(_mockIssueSource.Object);
        }

        [TestMethod]
        public void GetEmployee()
        {
            // Set up Prerequisites 
            //var controller = new EmployeeServiceController(_iempService);
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();

            // Act on Test
            var response = controller.GetEmployee();

            Assert.IsTrue(response.IsSuccessStatusCode);
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            // Assert the result
            //Employee employee;
            //Assert.IsTrue(response.TryGetContentValue<Employee>(out employee));
            //Assert.AreEqual("Susil Kumar Das", employee.Name);
        }
        [TestMethod]
        public void EmployeeGetById()
        {
            // Set up Prerequisites 
            //var controller = new EmployeeServiceController(_iempService);
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();

            // Act on Test
            var response = controller.GetEmployeeByID(3);

            // Assert the result
            Employee employee;
            Assert.IsTrue(response.TryGetContentValue<Employee>(out employee));
            Assert.AreEqual("Susil Kumar Das", employee.Name);
        }

        [TestMethod]
        public void EmployeeCreate()
        {
            // Set up Prerequisites 
            //var controller = new EmployeeServiceController(_iempService);
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();

            // Act on Test
            Employee employee = new Employee
            {
                Name = "Susil Kumar Das",
                DepartmentId = 1,
                Salary = 40000,
                EmailAddress = "test@gmail.com",
                PhoneNumber = "9778089858",
                Address = "Mindtree Kalinga",
                RmName = "Umashankar"
            };
            var response = controller.EmployeeCreate(employee);

            // Assert the result

            Assert.IsTrue(response.TryGetContentValue<Employee>(out employee));
            Assert.AreEqual("Susil Kumar Das", employee.Name);
        }

    }
}
