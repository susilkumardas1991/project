﻿using Autofac;
using EmpBusinessRes;
using EmpModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Http;
using Autofac.Integration.WebApi;
using EmpDataAccess;

namespace EmpService.App_Start
{
    public class AutoConfig
    {
        public static void Register()
        {

            var builder = new ContainerBuilder();
            var config = GlobalConfiguration.Configuration;
            builder.RegisterApiControllers(Assembly.GetExecutingAssembly());
            RegisterServices(builder);
            builder.RegisterWebApiFilterProvider(config);
            builder.RegisterWebApiModelBinderProvider();
            var container = builder.Build();
            config.DependencyResolver = new AutofacWebApiDependencyResolver(container);
        }


        private static void RegisterServices(ContainerBuilder builder)
        {
            builder.RegisterType<EmpContext>().InstancePerRequest();
            builder.RegisterType<EmpServices>()
                .As<IEmpService>()
                .InstancePerRequest();
        }
    }
}