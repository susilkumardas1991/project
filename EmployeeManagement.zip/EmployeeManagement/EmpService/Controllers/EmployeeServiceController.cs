﻿using EmpBusinessRes;
using EmployeeService.Infrastructure.Exception;
using EmpModel;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace EmpService.Controllers
{
    //[Route("api/emp")]
    public class EmployeeServiceController : ApiController
    {
        public IEmpService _empService;
        public EmployeeServiceController(IEmpService empService)
        {
            _empService = empService;
        }

        [HttpGet]
        public HttpResponseMessage GetEmployee()
        {
            try
            {
                List<Employee> employee = _empService.GetEmployee();
                if (employee == null)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound, "No Employee Found");
                }
                var json = JsonConvert.SerializeObject(employee);
                return Request.CreateResponse(HttpStatusCode.OK, json);
            }
            catch (EmpServiceException ex)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new EmpServiceException("Employee details not retrived '" + ex.Message + "'"));
            }
        }
        [HttpGet]
        //[Route("GetEmpById/{id}")]
        public HttpResponseMessage GetEmployeeByID(int id)
        {
            try
            {
                var employee = _empService.GetEmployeeByID(id);
                //var employee = context.Employees.Where(p => p.Id == id).FirstOrDefault();
                if (employee == null)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound);
                }
                var json = JsonConvert.SerializeObject(employee);
                return Request.CreateResponse(HttpStatusCode.OK, json);
            }
            catch (EmpServiceException ex)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new EmpServiceException("Employee details not retrived '" + ex.Message + "'"));
            }
        }

        [HttpPost]
        public HttpResponseMessage EmployeeCreate(Employee emp)
        {
            try
            {
                Employee empdata=_empService.Create(emp);
                if(empdata !=null)
                {
                    return Request.CreateResponse(HttpStatusCode.Created, emp);
                }
                return Request.CreateResponse(HttpStatusCode.NotFound, emp);
            }
            catch (EmpServiceException ex)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new EmpServiceException("Employee not saved due to '" + ex.Message + "'"));
            }
        }

        [HttpDelete]
        //[Route("DeleteEmp/{id}")]
        public HttpResponseMessage DeleteEmp(int id)
        {
            try
            {
                int data=_empService.Delete(id);
                if(data !=0)
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, "Employee ID '" + id + "' is deleted");
                }
                return Request.CreateResponse(HttpStatusCode.NotFound, "Employee ID '"+id+"' not found");
            }
            catch (EmpServiceException ex)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new EmpServiceException("Employee not deleted due to '" + ex.Message + "'"));
            }
        }
    }
}
