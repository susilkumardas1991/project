﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace EmployeeService.Infrastructure
{
    public class InternalServerErrorObjectResult
    {
        public InternalServerErrorObjectResult(object error)
        {

        }

    }
}