﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace EmpService.Models
{
    [Table("Employee")]
    public class Employee
    {
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; }

        public int DepartmentId { get; set; }

        public decimal? Salary { get; set; }

        [StringLength(255)]
        public string EmailAddress { get; set; }

        [StringLength(12)]
        public string PhoneNumber { get; set; }

        public string Address { get; set; }

        public string RmName { get; set; }

        public virtual Department Department { get; set; }

    }
}